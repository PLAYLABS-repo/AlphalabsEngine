/*********************

ImgDecode.h
Created by Josh Billena

*********************/

#ifndef IMGDECODE_H
#define IMGDECODE_H

#include "ImgData.h"
#include <FreeImage.h>

namespace Alphalabs{

    class ImgDecode{

    public:

        bool Decode(std::string Path, ImgData& Data);

        void Unload();

    private:

        FIBITMAP* Bitmap = nullptr;

    };

}

#endif // IMGDECODE_H
