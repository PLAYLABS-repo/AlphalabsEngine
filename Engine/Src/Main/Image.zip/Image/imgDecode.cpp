/*********************

ImgDecode.cpp
Created by Josh Billena

*********************/

#include "ImgDecode.h"

namespace Alphalabs{
    bool ImgDecode::Decode(std::string Path, ImgData& Data){
        FREE_IMAGE_FORMAT Format =
            FreeImage_GetFileType(Path.c_str(), 0);

        if (Format == FIF_UNKNOWN){
            Format =
                FreeImage_GetFIFFromFilename(Path.c_str());
        }

        if (Format == FIF_UNKNOWN){
            return false;
        }

        Bitmap = FreeImage_Load(
            Format,
            Path.c_str()
        );

        if (Bitmap == nullptr){
            return false;
        }

        Data.TargetImageWidth =
            FreeImage_GetWidth(Bitmap);

        Data.TargetImageHeight =
            FreeImage_GetHeight(Bitmap);

        return true;
    }

    void ImgDecode::Unload()
    {
        if (Bitmap != nullptr)
        {
            FreeImage_Unload(Bitmap);

            Bitmap = nullptr;
        }
    }
}
