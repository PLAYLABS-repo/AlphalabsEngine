/*********************

GLES2Framebuffer.h
Created by Josh Billena

*********************/

#ifndef GLES2_FRAMEBUFFER_H
#define GLES2_FRAMEBUFFER_H
#include <GLES2/gl2.h>
namespace Alphalabs{
  void GLES2CreateFramebuffer(GLuint& Framebuffer);
  void GLES2BeginFramebufferLayer(GLint Layer);
  void GLES2Layer(GLint Layer);
  bool GLES2CheckFramebuffer();
  void GLES2BindFramebuffer(GLuint Framebuffer);
  void GLES2BindDefaultFramebuffer();
  void GLES2CreateStencilBuffer(GLuint& StencilBuffer,GLsizei Width,GLsizei Height);
  void GLES2AttachStencilBuffer(GLuint StencilBuffer);

}
#endif // GLES2_FRAMEBUFFER_H

