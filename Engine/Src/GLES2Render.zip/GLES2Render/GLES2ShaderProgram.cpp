/*********************

GLES2ShaderProgram.h
Created by Josh Billena

*********************/


#include "GLES2ShaderProgram.h"
namespace Alphalabs{
    void GLES2CompileShaders(
    const char* VertexSource,
    const char* FragmentSource,
    GLuint& VertexShader,
    GLuint& FragmentShader
)
{
    // Creates the vertex shader object.
    VertexShader = glCreateShader(GL_VERTEX_SHADER);

    // Gives the vertex shader its source code.
    glShaderSource(
        VertexShader,
        1,
        &VertexSource,
        NULL
    );

    // Compiles the vertex shader.
    glCompileShader(VertexShader);


    // Creates the fragment shader object.
    FragmentShader = glCreateShader(GL_FRAGMENT_SHADER);

    // Gives the fragment shader its source code.
    glShaderSource(
        FragmentShader,
        1,
        &FragmentSource,
        NULL
    );

    // Compiles the fragment shader.
    glCompileShader(FragmentShader);
}


// Creates a shader program.
void GLES2CreateProgram(
    GLuint& Program
)
{
    // Creates an empty shader program.
    Program = glCreateProgram();
}


// Attaches vertex and fragment shaders to a program.
void GLES2AttachShaders(
    GLuint VertexShader,
    GLuint FragmentShader,
    GLuint Program
)
{
    // Attaches the vertex shader.
    glAttachShader(
        Program,
        VertexShader
    );

    // Attaches the fragment shader.
    glAttachShader(
        Program,
        FragmentShader
    );
}


// Assigns a shader attribute to a location.
void GLES2AssignAttribs(
    GLuint Program,
    GLuint Location,
    const char* Name
)
{
    // Assigns the attribute location before program linking.
    glBindAttribLocation(
        Program,
        Location,
        Name
    );
}


// Assigns a uniform value to a shader program.
void GLES2AssignUniform(
    GLuint Program,
    const char* Name,
    const void* Value
)
{
    // Gets the location of the uniform.
    GLint Location = glGetUniformLocation(
        Program,
        Name
    );

    // Stops if the uniform does not exist.
    if (Location < 0)
        return;

    /*
        The actual uniform type should be handled here.

        Example:
        GL_FLOAT
        GL_FLOAT_VEC2
        GL_FLOAT_VEC4
        GL_FLOAT_MAT4
        GL_INT
        GL_SAMPLER_2D

        The wrapper API can be expanded later so the user
        only needs one GLES2AssignUniform() call.
    */
}


// Links a shader program.
void GLES2LinkProgram(
    GLuint Program
)
{
    // Links all attached shaders into the program.
    glLinkProgram(Program);
}


// Uses a shader program.
void GLES2UseProgram(
    GLuint Program
)
{
    // Makes the program active.
    glUseProgram(Program);
}



}



