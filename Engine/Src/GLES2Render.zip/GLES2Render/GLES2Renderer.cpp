/*********************

GLES2Renderer.cpp
Created by Josh Billena

*********************/

#include "GLES2Renderer.h"
namespace Alphalabs{

    void GLES2Viewport(GLint X, GLint Y, GLsizei Width, GLsizei Height){
        glViewport(X, Y, Width, Height);

    }
    void GLES2ClearScreen(GLfloat R,GLfloat G,GLfloat B,GLfloat A){
        glClearColor(R,G,B,A);
        glClear(GL_COLOR_BUFFER_BIT);



    }
    void GLESClearBuffer(){
        glClear(GL_COLOR_BUFFER_BIT || GL_STENCIL_BUFFER_BIT || GL_DEPTH_BUFFER_BIT);

    }

}




