/*********************

GLES2Framebuffer.cpp
Created by Josh Billena

*********************/


#include "GLES2Framebuffer.h"

namespace Alphalabs{

void GLES2CreateFramebuffer(
    GLuint& Framebuffer
)
{

    glGenFramebuffers(
        1,
        &Framebuffer
    );
}


void GLES2BindFramebuffer(
    GLuint Framebuffer
)
{

    glBindFramebuffer(
        GL_FRAMEBUFFER,
        Framebuffer
    );
}


void GLES2BindDefaultFramebuffer()
{

    glBindFramebuffer(
        GL_FRAMEBUFFER,
        0
    );
}



void GLES2AttachTexture(
    GLuint Texture
)
{

    glFramebufferTexture2D(
        GL_FRAMEBUFFER,
        GL_COLOR_ATTACHMENT0,
        GL_TEXTURE_2D,
        Texture,
        0
    );
}



void GLES2CreateStencilBuffer(
    GLuint& StencilBuffer,
    GLsizei Width,
    GLsizei Height
)
{

    glGenRenderbuffers(
        1,
        &StencilBuffer
    );


    glBindRenderbuffer(
        GL_RENDERBUFFER,
        StencilBuffer
    );

    glRenderbufferStorage(
        GL_RENDERBUFFER,
        GL_STENCIL_INDEX8,
        Width,
        Height
    );
}



void GLES2AttachStencilBuffer(
    GLuint StencilBuffer
)
{

    glFramebufferRenderbuffer(
        GL_FRAMEBUFFER,
        GL_STENCIL_ATTACHMENT,
        GL_RENDERBUFFER,
        StencilBuffer
    );
}



bool GLES2CheckFramebuffer()
{

    GLenum Status = glCheckFramebufferStatus(
        GL_FRAMEBUFFER
    );


    return Status == GL_FRAMEBUFFER_COMPLETE;
}




void GLES2BeginFramebufferLayer(
    GLint Layer
)
{

    (void)Layer;
}





void GLES2Layer(
    GLint Layer
)
{

    (void)Layer;
}


}
