/*********************

GLES2StencilFunctions.cpp
Created by Josh Billena

*********************/

#include "GLES2Render.h"


namespace Alphalabs{
void GLES2InitStencilMask()
{

    glEnable(
        GL_STENCIL_TEST
    );

    glStencilFunc(
        GL_ALWAYS,
        1,
        0xFF
    );


    glStencilOp(
        GL_KEEP,
        GL_KEEP,
        GL_REPLACE
    );


    glStencilMask(
        0xFF
    );

    glColorMask(
        GL_FALSE,
        GL_FALSE,
        GL_FALSE,
        GL_FALSE
    );
}
void GLES2EndStencilMask()
{

    glColorMask(
        GL_TRUE,
        GL_TRUE,
        GL_TRUE,
        GL_TRUE
    );


    glStencilFunc(
        GL_EQUAL,
        1,
        0xFF
    );

    glStencilOp(
        GL_KEEP,
        GL_KEEP,
        GL_KEEP
    );


    glStencilMask(
        0x00
    );
}
void GLES2DisableStencilMask()
{

    glDisable(
        GL_STENCIL_TEST
    );


    glStencilMask(
        0xFF
    );


    glColorMask(
        GL_TRUE,
        GL_TRUE,
        GL_TRUE,
        GL_TRUE
    );
}

}
