/*********************

GLES2Buffer.cpp
Created by Josh Billena

*********************/

#include "GLES2Buffer.h"
namespace Alphalabs{
     void GLES2CreateVBO(
    GLuint& VBO,
    GLenum Target,
    GLsizeiptr Size,
    const void* Data,
    GLenum Usage
)
{

    glGenBuffers(
        1,
        &VBO
    );


    glBindBuffer(
        Target,
        VBO
    );

    glBufferData(
        Target,
        Size,
        Data,
        Usage
    );
}



void GLES2UseCurrent(
    GLuint Object,
    GLenum Target
)
{

    glBindBuffer(
        Target,
        Object
    );
}


}




