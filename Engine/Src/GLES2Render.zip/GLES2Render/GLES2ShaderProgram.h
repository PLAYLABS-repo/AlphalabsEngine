/*********************

GLES2ShaderProgram.h
Created by Josh Billena

*********************/

#ifndef GLES2_SHADER_PROGRAM_H
#define GLES2_SHADER_PROGRAM_H
#include <GLES2/gl2.h>
namespace Alphalabs{
    void GLES2CompileShaders(
    const char* VertexSource,
    const char* FragmentSource,
    GLuint& VertexShader,
    GLuint& FragmentShader
);


// Creates a shader program.
void GLES2CreateProgram(
    GLuint& Program
);


// Attaches vertex and fragment shaders to a program.
void GLES2AttachShaders(
    GLuint VertexShader,
    GLuint FragmentShader,
    GLuint Program
);

// Assigns a shader attribute to a location.
void GLES2AssignAttribs(
    GLuint Program,
    GLuint Location,
    const char* Name
);


// Assigns a uniform value to a shader program.
void GLES2AssignUniform(
    GLuint Program,
    const char* Name,
    const void* Value
);

// Links a shader program.
void GLES2LinkProgram(
    GLuint Program
);
// Uses a shader program.
void GLES2UseProgram(
    GLuint Program
);

}
#endif // GLES2_SHADER_PROGRAM_H

