/*********************

GLES2Render.h
Created by Josh Billena

*********************/

#ifndef GLES2_RENDER_H
#define GLES2_RENDER_H
#include <GLES2/gl2.h>
namespace Alphalabs{

   void GLES2DrawType(GLenum Type,GLint First,GLsizei Vertices);
   void GLES2DrawIndexed(GLenum Type,GLsizei Count,GLenum IndexType,const void* Indices);
   void GLES2SetBlendFunction(GLenum Source,GLenum Destination);
   void GLES2SetDepthTest(GLboolean Enabled);


}



#endif // GLES2_RENDER_H
