/*********************

GLES2Render.cpp
Created by Josh Billena

*********************/


#include "GLES2Render.h"

namespace Alphalabs{

   void GLES2DrawType(GLenum Type,GLint First,GLsizei Vertices){
      glDrawArrays(
          Type,
          First,
          Vertices
      );
   }
    void GLES2DrawIndexed(GLenum Type,GLsizei Count,GLenum IndexType,const void* Indices){
    glDrawElements(
        Type,
        Count,
        IndexType,
        Indices
    );
  }
  void GLES2SetCullFace(GLboolean Enabled){
    if (Enabled)
        glEnable(GL_CULL_FACE);
    else
        glDisable(GL_CULL_FACE);
  }
  void GLES2SetBlendFunction(GLenum Source,GLenum Destination){

    glBlendFunc(
        Source,
        Destination
    );
  }
   void GLES2SetDepthTest(GLboolean Enabled){

       if (Enabled)
           glEnable(GL_DEPTH_TEST);
       else
           glDisable(GL_DEPTH_TEST);
    }

}
