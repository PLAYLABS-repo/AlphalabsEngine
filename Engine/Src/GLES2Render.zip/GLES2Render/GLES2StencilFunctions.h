/*********************

GLES2StencilFunctions.h
Created by Josh Billena

*********************/

#ifndef GLES2_STENCIL_FUNCTS_H
#define GLES2_STENCIL_FUNCTS_H
#include <GLES2/gl2.h>
namespace Alphalabs{

void GLES2InitStencilMask();
void GLES2EndStencilMask();
void GLES2DisableStencilMask();

}
#endif // GLES_STENCIL_FUNCTS
