
/*********************

GLES2Attributes.h
Created by Josh Billena

*********************/
#ifndef GLES2_ATTRIBUTES_H
#define GLES2_ATTRIBUTES_H
#include <GLES2/gl2.h>
namespace Alphalabs{

void GLES2Attributes(
    GLuint Location,
    GLint Order,
    GLenum Type,
    GLboolean Normalize,
    GLsizei ByteSize,
    const void* StartData
);
}
#endif // GLES2_ATTRIBUTES_H
