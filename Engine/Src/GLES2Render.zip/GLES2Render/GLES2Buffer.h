/*********************

GLES2Buffer.h
Created by Josh Billena

*********************/

#ifndef GLES2_BUFFER_H
#define GLES2_BUFFER_H
#include <GLES2/gl2.h>
namespace Alphalabs{
     void GLES2CreateVBO(GLuint& VBO,GLenum Target,GLsizeiptr Size,const void* Data,GLenum Usage);


// Makes a buffer the current buffer.
void GLES2UseCurrent(GLuint Object,GLenum Target);


}
#endif // GLES2_RENDER_H


