/*********************

GLES2Textures.cpp
Created by Josh Billena

*********************/

#include "GLES2Textures.h"
namespace Alphalabs{
void GLES2CreateTexture(
    GLuint& Texture,
    GLsizei Width,
    GLsizei Height,
    GLenum Format,
    const void* Data
)
{

    glGenTextures(
        1,
        &Texture
    );


    glBindTexture(
        GL_TEXTURE_2D,
        Texture
    );


    glTexImage2D(
        GL_TEXTURE_2D,
        0,
        Format,
        Width,
        Height,
        0,
        Format,
        GL_UNSIGNED_BYTE,
        Data
    );
}


void GLES2BindTexture(
    GLuint Texture,
    GLuint Unit
)
{

    glActiveTexture(
        GL_TEXTURE0 + Unit
    );


    glBindTexture(
        GL_TEXTURE_2D,
        Texture
    );
}



void GLES2TextureParameters(
    GLenum MinFilter,
    GLenum MagFilter,
    GLenum WrapS,
    GLenum WrapT
)
{

    glTexParameteri(
        GL_TEXTURE_2D,
        GL_TEXTURE_MIN_FILTER,
        MinFilter
    );


    glTexParameteri(
        GL_TEXTURE_2D,
        GL_TEXTURE_MAG_FILTER,
        MagFilter
    );


    glTexParameteri(
        GL_TEXTURE_2D,
        GL_TEXTURE_WRAP_S,
        WrapS
    );


    glTexParameteri(
        GL_TEXTURE_2D,
        GL_TEXTURE_WRAP_T,
        WrapT
    );
}


}



